﻿#include "pch.h"
#include <iostream>
using namespace std;
struct lnode
{
	int key;    // wartość  użyteczna
	lnode *next; // wskażnik na następny węzeł
	lnode(int k, lnode* n) :key(k), next(n) {}

};
int nty(int n, lnode *root)
{
	
	if (root == nullptr) {
		return 0;
	}
	for (int i = 0; i <= n; i++) {
		root = root->next;
		if (root == nullptr) {
			return 0;
		}
	}
	return root->key;
}
int suma(lnode *L)
{
	int sum = 0;
	while (L)
	{
		sum += L->key;
		L = L->next;
	}
	return sum;
}
/*lnode* filter(lnode *L)
{
	lnode* temp;
	temp = L->next;
	while (L) {
		if (L->key < 0)
		{
			lnode *head;
			head = L->next;
			delete L;
		}
		if (temp->key < 0)
		{
			cout << "Ujemna " << temp->key << endl;
			L->next = temp->next;
			delete temp;
		}
		temp = temp->next;
		//L = L->next;
	}
	return L;
}*/

int main()
{
	lnode* L = new lnode(5, nullptr);
	L = new lnode(-3, L);
	L = new lnode(2, L);
	L = new lnode(-10, L);


	cout<<"N-ty element: "<< nty(0, L) << endl;
	cout<<"Suma elementow listy: "<< suma(L) << endl;
	cout << "Lista przed filtrem: " << endl;
	for (int i = 0; i <= 3; i++) {
		cout<<nty(i,L)<< " ";
	};
	/*filter(L);
	cout << nty(0, L) << endl;*/
	delete L;
	return 0;
}

